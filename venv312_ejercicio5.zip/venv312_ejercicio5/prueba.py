from os import system
import modules.clases as clases
import msvcrt

def figures():   
    system('cls')
    print("Bienvenido a la calculadora de perímetro y área")
    print("¿Desea calcular el área y perímetro de: círculo=1, triángulo=2 o rectángulo=3?")
    
    dato = None
    while dato not in ["1", "2", "3"]:
        dato = msvcrt.getwch()
        
    if dato == "1":
        circle = clases.circulo()
        circle.radio = int(input("Radio del círculo: "))
        print(f"Área del círculo: {circle.area_circulo()}")
        print(f"Perímetro del círculo: {circle.perimetro_circulo()}")
    elif dato == "2":
        triangle = clases.triangulo()
        triangle.a = int(input("Cateto a del triángulo: "))
        triangle.b = int(input("Cateto b del triángulo: "))
        triangle.c = int(input("Cateto c del triángulo: "))
        print(triangle)
    elif dato == "3":
        rectangle = clases.rectangulo()
        rectangle.largo = int(input("Largo del rectángulo: "))
        rectangle.ancho = int(input("Ancho del rectángulo: "))
        print(f"Área del rectángulo: {rectangle.area_rectangulo()}")
        print(f"Perímetro del rectángulo: {rectangle.perimetro_rectangulo()}")

if __name__ == "__main__":
    figures()