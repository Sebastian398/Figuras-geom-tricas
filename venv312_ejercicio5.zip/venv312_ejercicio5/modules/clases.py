#*****
#Centro de Biotecnologia Agropecuaria
#Ficha:2877795
#aprendiz: Neider Sebastian Ramirez Delgadillo
#Version:3.12
#Fecha:06/05/2024
#*****

#Se importan las librerias
from os import system
import math

'''
Este programa calcula el area y perimetro del circulo, el rectangulo y el triangulo
'''

class Aprendiz:
    # Metodo constructor :: Funcion constructora :: Funcion que instancia objetos
    #Self: pronombre del objeto para hablar de si mismo
    # Documento: es de tipo string con un tamaño minimo de 7 y maximo de 10 caracteres
    # Ficha: es de tipo string con un tamaño minimo de 7 caracteres
   
    def __init__(self, documento, nombre, ficha, evaluacion):
        self.__documento = documento
        self.__nombre = nombre
        self.__ficha = ficha
        self.__evaluacion = evaluacion
    
    # Metodos Getter y Setter de la Clase :: HTTP : Metodos SET y POST 

    def set_documento(self,documento):
        self.__documento = documento

    def get_documento(self):
        return self.__documento
    
    def set_nombre(self, nombre):
        self.__nombre = nombre
    
    def get_nombre(self):
        return self.__nombre
    
    def set_ficha(self, ficha):
        self.__ficha = ficha
    
    def get_ficha(self):
        return self.__ficha
    
    
    def set_evaluacion(self, evaluacion):
        self.__evaluacion = evaluacion
    
    def get_evaluacion(self):
        return self.__evaluacion

    def mostrar_nombre(self):
        print('El nombre del aprendiz es', self.__nombre)
    
    def mostrar_documento(self):
        print('El documento del aprendiz es', self.__documento)
    
    def mostrar_ficha(self):
        print('La ficha del aprendiz es', self.__ficha)
    
    def mostrar_evaluacion(self):
        print('La evaluacion del aprendiz es', self.__evaluacion)

    def informacion_aprendiz(self):
        system('cls')
        print('Mi nombre es {0}, mi documento es {1}, mi numero de ficha es {2}, mi evaluacion es {3}'.format(self.get_nombre(), self.get_documento(), self.get_ficha(), self.get_evaluacion(), end=""))

#Se crea la clase circulo
class circulo:

    #Se crea el atributo radio
    def __init__(self, radio=0):
        self.__radio = radio

    @property
    def radio(self):
        return self.__radio

    @radio.setter
    def radio(self, value):
        self.__radio = value

    #Se calculan el area y el perimetro
    def area_circulo(self):
        return math.pi * self.radio ** 2

    def perimetro_circulo(self):
        return 2 * math.pi * self.radio

#Se crea la clase triangulo
class triangulo:
        
        #Se crean los atributos para los catetos a, b, c
        def __init__(self, a=0, b=0, c=0):
            self.__a = a
            self.__b = b
            self.__c = c
        
        @property
        def a(self):
            return self.__a

        @a.setter
        def a(self, value):
            self.__a = value

        @property
        def b(self):
            return self.__b

        @b.setter
        def b(self, value):
            self.__b = value

        @property
        def c(self):
            return self.__c

        @c.setter
        def c(self, value):
            self.__c = value

        #Se calculan el area y el perimetro
        def area_triangulo(self):
            s = (self.a + self.b + self.c) / 2
            return math.sqrt(s * (s - self.a) * (s - self.b) * (s - self.c))

        def perimetro_triangulo(self):
            return self.a + self.b + self.c
        
#Se crea la clase rectangulo        
class rectangulo:

    #Se crean los atributos largo y ancho
    def __init__(self, ancho=0, largo=0): 
        self.__ancho = ancho 
        self.__largo = largo
    
    @property
    def ancho(self):
        return self.__ancho

    @ancho.setter
    def ancho(self, value):
        self.__ancho = value

    @property
    def largo(self):
        return self.__largo

    @largo.setter
    def largo(self, value):
        self.__largo = value

    #Se calculan el area y el perimetro
    def area_rectangulo(self):
        return self.ancho * self.largo

    def perimetro_rectangulo(self):
        return 2 * (self.ancho + self.largo)