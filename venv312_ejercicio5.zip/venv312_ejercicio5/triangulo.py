from os import system
import modules.clases as clases
def main():    
    #circle es una instancia de clase circulo
    circle = clases.circulo('', '', '', '')

    print("Circulo del aprendiz", circle.get_circunferencia())

    print("Area del aprendiz", circle.get_area())

    print("Perimetro del aprendiz", circle.get_perimetro())

    print("Informacion del circulo", circle.get_informacion_circulo())

    circle.mostrar_circunferencia()
    circle.mostrar_area()
    circle.mostrar_perimetro()
    circle.informacion_circulo()