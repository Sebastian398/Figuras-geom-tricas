#*****
#Centro de Biotecnologia Agropecuaria
#Ficha:2877795
#aprendiz: Neider Sebastian Ramirez Delgadillo
#Version:3.12
#Fecha:06/06/2024
#*****

#Se importan las bibliotecas
from turtle import *
import modules.clases as clases

'''
Este programa muestra el calculo del area y el perimetro de un circulo, un rectangulo y un triangulo solicitando sus respectivas medidas
'''
#Se instancian las clases
rectangle = clases.rectangulo()
circle = clases.circulo()
triangle = clases.triangulo()

def figures():

    print("Bienvenido a la calculadora de permietro y area")
    print("A continuacion va a calcular el area y perimetro del circulo, el triangulo y el rectangulo")

    #Se ingresa el radio
    circle.radio = int(input("radio del circulo: "))
    
    #Imprimir el area y el perimetro
    print(f"Area del circulo: {circle.area_circulo():.2f}")
    print(f"Perimetro del circulo: {circle.perimetro_circulo():.2f}")

   #Se ingresan los catetos
    while True:
        try:
            triangle.a = int(input("cateto a del triangulo: "))
            triangle.b = int(input("cateto b del triangulo: "))
            triangle.c = int(input("cateto c del triangulo: "))
            
            #Imprimir el area y el perimetro
            print(f"Area del triangulo: {triangle.area_triangulo():.2f}")
            print(f"Perimetro del triangulo: {triangle.perimetro_triangulo():.2f}")
            break
        except ValueError:
            print("Por favor ingrese valores que coincidan")

    #Se ingresa el largo y ancho
    rectangle.largo = (int(input("largo del rectangulo: ")))
    rectangle.ancho = (int(input("ancho del rectangulo: ")))
    
    #Imprimir el area y el perimetro
    print(f"Area del rectangulo: {rectangle.area_rectangulo()}")
    print(f"Perimetro del rectangulo: {rectangle.perimetro_rectangulo()}")


def imprimir():
    tabla = """
+------------------------------------------------------------------------------------------------------------+
|                                          FIGURAS GEOMETRICAS                                               |
|------------------------------------------------------------------------------------------------------------|
| FIGURA          PARAMETROS                                               AREA     PERIMETRO                |
|------------------------------------------------------------------------------------------------------------|
"""
    param_rect = 'Ancho: {0} Largo: {1}'.format(format(rectangle.ancho, '.2f'),
                                                format(rectangle.largo, '.2f'))

    param_circ = 'Radio: {0}'.format(format(circle.radio, '.2f'))

    param_tria = 'Cateto a: {0} Cateto b: {1} Cateto c: {2}'.format(format(triangle.a, '.2f'),
                                                                    format(triangle.b, '.2f'),
                                                                    format(triangle.c, '.2f'))

    tabla = tabla + '{4}{0:<15s} {1:<55s} {2:<10s} {3:23s} {4}\n'.format(
            'Rectangulo', param_rect, format(rectangle.area_rectangulo(), '.2f'), 
                format(rectangle.perimetro_rectangulo(), '.2f'), '| ')

    tabla = tabla + '{4}{0:<15s} {1:<55s} {2:<10s} {3:23s} {4}\n'.format(
            'Circulo', param_circ, format(circle.area_circulo(), '.2f'),
                format(circle.perimetro_circulo(), '.2f'), '| ')

    tabla = tabla + '{4}{0:<15s} {1:<55s} {2:<10s} {3:23s} {4}\n'.format(
            'Triangulo', param_tria, format(triangle.area_triangulo(), '.2f'),
                format(triangle.perimetro_triangulo(), '.2f'), '| ')

    tabla = tabla + "+------------------------------------\
------------------------------------------------------------------------+\n"

    print(tabla)
    print("Gracias por usar el programa")

if __name__ == "__main__":
    #Ejecutar el programa
    figures()
    imprimir()