#*****
#Centro de Biotecnologia Agropecuaria
#Ficha:2877795
#aprendiz: Neider Sebastian Ramirez Delgadillo
#Version:3.12
#Fecha:06/06/2024
#*****

#Se importan las bibliotecas
from os import system
from turtle import *
import modules.clases as clases
import msvcrt

'''
Este programa muestra el calculo del area y el perimetro de un circulo, un rectangulo y un triangulo solicitando sus respectivas medidas
'''

def figures():
    #Se limpia el espacio antes de comenzar con el programa   
    system('cls')
    print("Bienvenido a la calculadora de permietro y area")
    print("desea calcular el area y perimetro de: circulo=1 triangulo=2 rectangulo=3")
    
    dato = None

    #Opciones ejecutables segun la eleccion del usuario
    while dato not in ["1", "2", "3"]:
        dato = msvcrt.getwch()
        
        if dato == "1":
            #Circle es una instancia de clase circulo
            circle = clases.circulo()
            #Se ingresa el radio
            circle.radio = int(input("radio del circulo: "))
            
            #Imprimir el area y el perimetro
            print(f"Area del circulo: {circle.area_circulo():.2f}")
            print(f"Perimetro del circulo: {circle.perimetro_circulo():.2f}")

            #Regresar al menu
            print("¿Desea volver al menu? s/n")
            dato1 = None
            while dato1 not in ["s", "n"]:
                dato1 = msvcrt.getwch()
                if dato1 == "s":
                    figures()
                elif dato1 == "n":
                    print("Gracias por usar el programa")

        elif dato == "2":
            #Triangle es una instancia de clase triangulo
            triangle = clases.triangulo()

            #Se ingresan los catetos
            while True:
                try:
                    triangle.a = int(input("cateto a del triangulo: "))
                    triangle.b = int(input("cateto b del triangulo: "))
                    triangle.c = int(input("cateto c del triangulo: "))
                    
                    #Imprimir el area y el perimetro
                    print(f"Area del triangulo: {triangle.area_triangulo():.2f}")
                    print(f"Perimetro del triangulo: {triangle.perimetro_triangulo():.2f}")
                    break
                except ValueError:
                    print("Por favor ingrese valores que coincidan con la validacion a+b>c")

            #Regresar al menu
            print("¿Desea volver al menu? s/n")
            dato1 = None
            while dato1 not in ["s", "n"]:
                dato1 = msvcrt.getwch()
                if dato1 == "s":
                    figures()
                elif dato1 == "n":
                    print("Gracias por usar el programa")  

        elif dato == "3":

            #Rectangle es una instancia de clase rectangle
            rectangle = clases.rectangulo()

            #Se ingresa el largo y ancho
            rectangle.largo = int(input("largo del rectangulo: "))
            rectangle.ancho = int(input("ancho del rectangulo: "))
            
            #Imprimir el area y el perimetro
            print(f"Area del rectangulo: {rectangle.area_rectangulo()}")
            print(f"Perimetro del rectangulo: {rectangle.perimetro_rectangulo()}")

            #Regresar al menu
            print("¿Desea volver al menu? s/n")
            dato1 = None
            while dato1 not in ["s", "n"]:
                dato1 = msvcrt.getwch()
                if dato1 == "s":
                    figures()
                elif dato1 == "n":
                    print("Gracias por usar el programa")

if __name__ == "__main__":
    #Ejecutar el programa
    figures()