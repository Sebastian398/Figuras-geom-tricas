#Nombre variables: snake case :: radio - radio_circulo
#Nomobre de las clases: camel case :: Circulo_Plazoleta
from os import system
import modules.clases as clases
def main():    
    #aprendiz1 es una instancia de clase Aprendiz
    aprendiz1 = clases.Aprendiz('', '', '', '')

    aprendiz1.set_documento(input("documento del aprendiz: "))

    print("Documento del aprendiz", aprendiz1.get_documento())

    aprendiz1.set_nombre(input("nombre del aprendiz: "))

    print("Nombre del aprendiz", aprendiz1.get_nombre())

    aprendiz1.set_ficha(input("ficha del aprendiz: "))

    print("Ficha del aprendiz", aprendiz1.get_ficha())

    aprendiz1.set_evaluacion(input("evaluacion del aprendiz: "))

    print("evaluacion del aprendiz", aprendiz1.get_evaluacion())

    aprendiz1.mostrar_nombre()
    aprendiz1.mostrar_documento()
    aprendiz1.mostrar_ficha()
    aprendiz1.mostrar_evaluacion()
    aprendiz1.informacion_aprendiz()

if __name__ == "__main__":
    main()